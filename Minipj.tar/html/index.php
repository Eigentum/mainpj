<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Web Vulnerability Practice</title>
    <link rel="stylesheet" href="./assets/css/styles.css">
    <style>

	.container {
		max-width: 1000px;
		margin: 0 auto;
		padding: 20px;
		text-align: center;
	}

        body, html {
            height: 100%;
            margin: 0;
        }
        
        .wrapper {
            display: flex;
            flex-direction: column;
            min-height: 100vh;
        }
        footer {
		background: #35424a;
		color: #ffffff;
		text-align: center;
		padding: 10px;
		margin-top: auto;
	} 
 
    </style>
</head>
<body>
    <div class="wrapper">
        <header>
            <div class="container">
                <h1>Web Vulnerability Practice</h1>
                <ul>
                    <li><a href="index.php">Home</a></li>
                    <li><a href="sqli.php">SQL Injection</a></li>
                    <li><a href="./xss/xss_intro.php">XSS</a></li>
                    <li><a href="csrf.php">CSRF</a></li>
                    <li><a href="DirIndexing/DirIndexing.php">Directory Indexing</a></li>
                    <li><a href="FileUploadVuln.php">File Upload Vulnerability</a></li>
                </ul>
            </div>
        </header>

        <div class="container">
            <h2>Welcome to Web Vulnerability Practice!</h2>
            <p>Select a vulnerability type from the menu to start practicing.</p>
        </div>
        
        <footer>
            <p>Web Vulnerability Practice &copy; 2024</p>
        </footer>
    </div>
</body>
</html>
