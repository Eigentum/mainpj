<?php
// 콜백 함수 이름을 GET 파라미터로 받음
$callback = isset($_GET['callback']) ? $_GET['callback'] : null;

// 반환할 데이터 (예: JSON 데이터)
$data = array(
    "message" => "This is a JSONP response",
    "status" => "success"
);

// JSON 데이터를 생성
$jsonData = json_encode($data);

// 콜백 함수가 있을 경우, JSONP 형식으로 응답
if ($callback) {
    header('Content-Type: application/javascript');
    echo $callback . '(' . $jsonData . ');';
} else {
    // 콜백 함수가 없을 경우, 일반 JSON 반환
    header('Content-Type: application/json');
    echo $jsonData;
}
?>

